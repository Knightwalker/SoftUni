<?php

namespace EShopBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EShopBundle extends Bundle
{
}
