<?php

namespace EShopBundle\Repository;


/**
 * This custom Doctrine repository is empty because so far we don't need any custom
 * method to query for application user information. But it's always a good practice
 * to define a custom repository that will be used when the application grows.
 *
 */
class UserRepository extends \Doctrine\ORM\EntityRepository
{

}
