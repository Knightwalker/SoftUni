#include <iostream>
#include <string>
#include <sstream>
#include <map>

enum Indexes
{
    ODD_ELEMENTS,
    EVEN_ELEMENTS,

    INDEXES_COUNT
};


int main()
{
    std::string input;
    getline(std::cin, input);

    std::istringstream istr(input);
    std::string word;

    std::map<std::string, int> wordsCounter;

    while(istr >> word)
    {
        ++wordsCounter[word];
    }

    std::ostringstream elements[INDEXES_COUNT];

    for(const std::pair<std::string, int> & elem : wordsCounter)
    {
        elements[elem.second & 1] << elem.first << ' ';

//        if(elem.second & 1) //odd
//        {
//            elements[ODD_ELEMENTS] << elem.first << ' ';
//        }
//        else //even
//        {
//            elements[EVEN_ELEMENTS] << elem.first << ' ';
//        }
    }

    std::cout << elements[ODD_ELEMENTS].str() << '\n'
              << elements[EVEN_ELEMENTS].str() << '\n';

	return 0;
}
